import csv
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
import h5py
import numpy as np
import cv2
import tensorflow as tf
from tensorflow.python.keras.layers import Input, Dense

from matplotlib import pyplot as plt
from tensorflow import keras
import pandas
from sklearn.model_selection import train_test_split
from keras.models import Sequential
from keras.layers import Dense, Dropout, Activation, Flatten
from keras.layers import Convolution2D, MaxPooling2D
from keras.utils import np_utils
from keras.models import Model
from keras.layers import GlobalAveragePooling2D
from keras.losses import binary_crossentropy
from keras import callbacks
from tensorflow.keras.layers import BatchNormalization
from keras.layers import Conv2D, MaxPooling2D , UpSampling2D ,Conv2DTranspose

from keras.applications.resnet50 import ResNet50, preprocess_input

#load SynthText data into train set
file_name1= '/content/drive/MyDrive/Project_Vision/SynthText.h5'
file_name2=  '/content/drive/MyDrive/Project_Vision/SynthText_val.h5'
file_name3=  '/content/drive/MyDrive/Project_Vision/train.h5'
file_name4=  '/content/drive/MyDrive/Project_Vision/test.h5'
weightsPath='/content/drive/MyDrive/Project_Vision/WeightsFina3.h5'
modelPath='/content/drive/MyDrive/Project_Vision/modelFinal3.json'

db = h5py.File(file_name1, 'r')
im_namesTr = list(db['data'].keys())
Label={'Skylark':0,'Sweet Puppy':1,'Ubuntu Mono':2}
CounterLabelTr={'Skylark':0,'Sweet Puppy':0,'Ubuntu Mono':0}

X_train=[]
Y_train=[]
X_test=[]
Y_test=[]
counterTrainCh=0
# Preprocess input data
n=64
db = h5py.File(file_name1, 'r')
im_namesTr = list(db['data'].keys())
for im in im_namesTr:           
        img = db['data'][im][:]
        font = db['data'][im].attrs['font']
        txt = db['data'][im].attrs['txt']
        charBB = db['data'][im].attrs['charBB']
        wordBB = db['data'][im].attrs['wordBB']                      
        charBB_T = charBB.transpose(2, 0, 1)        
        j = 0
        for bb in charBB_T:           
                counterTrainCh+=1
                pts1 = np.float32([bb.T[0], bb.T[1], bb.T[3], bb.T[2]])
                pts2 = np.float32([[0, 0], [n, 0], [0, n], [n, n]])
                M = cv2.getPerspectiveTransform(pts1, pts2)
                dst = cv2.warpPerspective(img, M, (n, n))
                X_train.append(dst) 
                CounterLabelTr[font[j].decode('UTF-8')]+=1              
                Y_train.append(Label[font[j].decode('UTF-8')])
                j += 1
db = h5py.File(file_name2, 'r')
im_namesTr = list(db['data'].keys())
for im in im_namesTr:           
        img = db['data'][im][:]
        font = db['data'][im].attrs['font']
        txt = db['data'][im].attrs['txt']
        charBB = db['data'][im].attrs['charBB']
        wordBB = db['data'][im].attrs['wordBB']                      
        charBB_T = charBB.transpose(2, 0, 1)        
        j = 0
        for bb in charBB_T:           
                counterTrainCh+=1
                pts1 = np.float32([bb.T[0], bb.T[1], bb.T[3], bb.T[2]])
                pts2 = np.float32([[0, 0], [n, 0], [0, n], [n, n]])
                M = cv2.getPerspectiveTransform(pts1, pts2)
                dst = cv2.warpPerspective(img, M, (n, n))
                X_train.append(dst) 
                CounterLabelTr[font[j].decode('UTF-8')]+=1              
                Y_train.append(Label[font[j].decode('UTF-8')])
                j += 1
db = h5py.File(file_name3, 'r')
im_namesTr = list(db['data'].keys())
for im in im_namesTr:           
        img = db['data'][im][:]
        font = db['data'][im].attrs['font']
        txt = db['data'][im].attrs['txt']
        charBB = db['data'][im].attrs['charBB']
        wordBB = db['data'][im].attrs['wordBB']                      
        charBB_T = charBB.transpose(2, 0, 1)        
        j = 0
        for bb in charBB_T:           
                counterTrainCh+=1
                pts1 = np.float32([bb.T[0], bb.T[1], bb.T[3], bb.T[2]])
                pts2 = np.float32([[0, 0], [n, 0], [0, n], [n, n]])
                M = cv2.getPerspectiveTransform(pts1, pts2)
                dst = cv2.warpPerspective(img, M, (n, n))
                X_test.append(dst) 
                CounterLabelTr[font[j].decode('UTF-8')]+=1              
                Y_test.append(Label[font[j].decode('UTF-8')])
                j += 1
                

print(counterTrainCh)
# db = h5py.File(file_name4, 'r')
# im_namesVal = list(db['data'].keys())
# X_test=[]
# Y_test=[]
# index=0
# counterValCh=0
# CounterLabelVal={'Skylark':0,'Sweet Puppy':0,'Ubuntu Mono':0}
# for im in im_namesVal:             
#         img = db['data'][im][:]
#         #font = db['data'][im].attrs['font']
#         txt = db['data'][im].attrs['txt']
#         charBB = db['data'][im].attrs['charBB']
#         wordBB = db['data'][im].attrs['wordBB']       
#         size=0;                
#         charBB_T = charBB.transpose(2, 0, 1)        
#         j = 0
#         for bb in charBB_T:            
#                 counterValCh+=1
#                 pts1 = np.float32([bb.T[0], bb.T[1], bb.T[3], bb.T[2]])
#                 pts2 = np.float32([[0, 0], [n, 0], [0, n], [n, n]])
#                 M = cv2.getPerspectiveTransform(pts1, pts2)
#                 dst = cv2.warpPerspective(img, M, (n, n))
#                 X_test.append(dst)
#                 CounterLabelVal[font[j].decode('UTF-8')]+=1
#                 Y_test.append(Label[font[j].decode('UTF-8')])
#                 j += 1 

#print(counterValCh)
X_train= np.asarray(X_train)
X_test= np.asarray(X_test)
Y_train=np.asarray(Y_train)
Y_test=np.asarray(Y_test)
X_train= X_train.transpose(0,3,1,2)
X_test= X_test.transpose(0,3,1,2)
X_train= X_train.astype('float32')
X_test= X_test.astype('float32')
X_train/=255
X_test/=255


# 6. Preprocess class labels
n_classes = 3 
Y_train = np_utils.to_categorical(Y_train,num_classes= n_classes)
Y_test = np_utils.to_categorical(Y_test,num_classes= n_classes)




# 7. Define model architecture

nb_filters = 128
batch_size = 128
epochs = 100
nb_classes = 3
pool_size = (12, 12)
kernel_size = (3, 3)
img_rows = 32
img_cols = 32
input_shape = (3,img_rows, img_cols)

model = Sequential()
# Cu Layers 
model = Sequential()
model.add(Convolution2D(nb_filters,kernel_size= kernel_size, activation='relu', input_shape=(3,n,n),data_format='channels_first'))
model.add(Convolution2D(nb_filters,kernel_size=kernel_size, activation='relu'))
model.add(BatchNormalization()) 
model.add(MaxPooling2D(pool_size=pool_size))

#cy Layers
model.add(Dropout(0.25)) 
model.add(Flatten())
model.add(Dense(3000, input_dim=8, activation='relu'))
model.add(Dropout(0.5))
model.add(Dense(300, activation='relu'))
model.add(Dropout(0.5))
model.add(Dense(3, activation='softmax'))


# 8. Compile model
from keras.optimizers import Adam
opt = Adam(lr=0.0001)
model.compile(loss='categorical_crossentropy',
              optimizer=opt,
              metrics=['accuracy'])
early_stopping=callbacks.EarlyStopping(monitor='val_loss', min_delta=0, patience=10, verbose=0, mode='min')
filepath="/content/drive/MyDrive/Project_Vision/top_model.h5"
checkpoint = callbacks.ModelCheckpoint(filepath, monitor='val_loss', verbose=1, save_best_only=True, mode='min')
callbacks_list = [early_stopping,checkpoint]

history = model.fit(X_train, Y_train,shuffle=True,batch_size=batch_size,epochs=epochs,verbose=1,validation_data=(X_test, Y_test))

# 10. Evaluate model on test data
score = model.evaluate(X_test, Y_test, verbose=0)
print('Test loss:', score[0])
print('Test accuracy:', score[1])

metric_name='accuracy'
metric = history.history[metric_name]
val_metric = history.history['val_' + metric_name]    
e = range(1, epochs + 1)   
plt.figure(figsize=(20,10))
plt.plot(e, metric, label='Train ' + metric_name)
plt.plot(e, val_metric, label='Validation ' + metric_name)
plt.xlabel('Epoch number')
plt.ylabel(metric_name)
plt.title('Comparing training and validation ' + metric_name + ' for ' + model.name)

metric_name='loss'
metric = history.history[metric_name]
val_metric = history.history['val_' + metric_name]    
e = range(1, epochs + 1)   
plt.figure(figsize=(20,10))
plt.plot(e, metric, label='Train ' + metric_name)
plt.plot(e, val_metric, label='Validation ' + metric_name)
plt.xlabel('Epoch number')
plt.ylabel(metric_name)
plt.title('Comparing training and validation ' + metric_name + ' for ' + model.name)
plt.legend()
plt.show()
print(model.summary())


# serialize model to JSON
model_json = model.to_json()
with open(modelPath, "w") as json_file:
    json_file.write(model_json)
# serialize weights to HDF5
model.save_weights(weightsPath)
print("Saved model to disk")



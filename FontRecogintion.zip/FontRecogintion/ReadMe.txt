hey!
link for drive: 
"https://drive.google.com/drive/folders/17IUYVrB3OrISNX_AnUilr4qnRkqM-1-A?usp=sharing"
This folder contains the following folders:
1. Final_Model:
	1.FinalModel.py- code for the fit  final model
	2. PredictFinalModel.py- code for the predict final model
	3. Results.csv - csv file with Results from to predict final model
	4. ModelFinal.json model json file
	5. WeightsFinal.h5 weight h5 file
	6. images of loss accuracy and summry 
2. Final_Model2:
	1.FinalModel2.py- code for the fit  final model
	2. PredictFinalModel2.py- code for the predict final model
	3. Results2.csv - csv file with Results from to predict final model
	4. ModelFinal2.json model json file
	5. WeightsFinal2.h5 weight h5 file
	6. images of loss accuracy and summry 
3. Final_Model3:
	1.FinalModel3.py- code for the fit  final model
	2. PredictFinalModel3.py- code for the predict final model
	3. Results3.csv - csv file with Results from to predict final model
	4. ModelFinal3.json model json file
	5. WeightsFinal3.h5 weight h5 file
	6. images of loss accuracy and summry 
4. set:
	1. SynthText.h5
	2. SynthText_val.h5
	3.train.h5
	4. test.h5

5. ReadMEFinal_Model_i- readme for Final_Model.py
6. PredictFinalModel_i.py- code for the predict final model
7. ReadMEPredictFinalModel_i- readme PredictFinalModel.py
8. ReportProject - file explain what i did in project

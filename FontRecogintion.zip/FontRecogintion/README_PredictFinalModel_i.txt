Hey,

This script is PredictFinal model  to predict with loaded model from the Final_Model.py and create csv file for the results 
 
Please make sure that the following prerequisites are fulfilled before running 'PredictFinalModel.py':

1) Python 3 should be installed.
2) Python should be part of the PATH environment variable (for windows).
3) The following external libraries are required:
	1. tensorflow
	2. keras
4) The following file structure is expected:
	path varible names in script:
              file_name4 ,weightsPath,modelPath	
 	file_name4- path to test.h5'
	CSV_path- path to Results.csv'
	weightsPath- path to 'WeightsFinal.h5'
	modelPath- path to 'modelFinal.json'
	you need change the path all of them
5) Folder was too big so It is available in a pubic folder of my google drive here:

"https://drive.google.com/drive/folders/17IUYVrB3OrISNX_AnUilr4qnRkqM-1-A?usp=sharing"
6) End.
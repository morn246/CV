# -*- coding: utf-8 -*-
"""
Created on Sat Jan 23 18:07:10 2021

@author: 97252
"""

import csv
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
import h5py
import numpy as np
import cv2
import tensorflow as tf
from tensorflow.python.keras.layers import Input, Dense
from keras.models import model_from_json
from matplotlib import pyplot as plt
from tensorflow import keras
import pandas
from sklearn.model_selection import train_test_split
from keras.models import Sequential
from keras.layers import Dense, Dropout, Activation, Flatten
from keras.layers import Convolution2D, MaxPooling2D
from keras.utils import np_utils
from keras.models import Model
from keras.layers import GlobalAveragePooling2D
from keras.losses import binary_crossentropy
from keras import callbacks
from tensorflow.keras.layers import BatchNormalization
from keras.layers import Conv2D, MaxPooling2D , UpSampling2D ,Conv2DTranspose
from keras.models import model_from_json
from keras.applications.resnet50 import ResNet50, preprocess_input

Label={'Skylark':0,'Sweet Puppy':1,'Ubuntu Mono':2}
file_name4= '/content/drive/MyDrive/Project_Vision/test.h5'
CSV_path='/content/drive/MyDrive/Project_Vision/Results2.csv'
weightsPath='/content/drive/MyDrive/Project_Vision/WeightsFinal2.h5'
modelPath='/content/drive/MyDrive/Project_Vision/modelFinal2.json'

db = h5py.File(file_name4, 'r')
im_namesVal = list(db['data'].keys())
X_test=[]
image_ls=[]
Char_ls=[]
SN_ls=[]
Y_test=[]
index=0
counterValCh=0
CounterLabelVal={'Skylark':0,'Sweet Puppy':0,'Ubuntu Mono':0}
n=28
for im in im_namesVal:             
        img = db['data'][im][:]
        #font = db['data'][im].attrs['font']
        txt = db['data'][im].attrs['txt']
        charBB = db['data'][im].attrs['charBB']
        wordBB = db['data'][im].attrs['wordBB'] 
        size=0;
        for i in range(len(txt)):            
            size+= len(txt[i-1])
            for tx in range(len(txt[i])):
                image_ls.append(im)                
                t=txt[i][tx]       
                Char_ls.append(chr(t))
                SN_ls.append(index)
                index+=1
                
                
                        
        charBB_T = charBB.transpose(2, 0, 1)        
        j = 0
        for bb in charBB_T:            
                counterValCh+=1
                pts1 = np.float32([bb.T[0], bb.T[1], bb.T[3], bb.T[2]])
                pts2 = np.float32([[0, 0], [n, 0], [0, n], [n, n]])
                M = cv2.getPerspectiveTransform(pts1, pts2)
                dst = cv2.warpPerspective(img, M, (n, n))
                X_test.append(dst)
                j += 1 

X_test= np.asarray(X_test)
X_test= X_test.transpose(0,3,1,2)
X_test= X_test.astype('float32')
X_test/=255

# load json and create model
json_file = open(modelPath, 'r')
loaded_model_json = json_file.read()
json_file.close()
loaded_model = model_from_json(loaded_model_json)
# load weights into new model
loaded_model.load_weights(weightsPath)
print("Loaded model from disk")

Results= np.argmax(loaded_model.predict(X_test), axis=-1)


#CSV_path='ResultsT.csv'
with open(CSV_path, mode='w', newline='') as csv_file:
         writer = csv.writer(csv_file)
         writer.writerow(["SN", "image", "Char", "Skylark", "Sweet Puppy", "Ubuntu Mono"])
         for i in SN_ls:
             v=[0,0,0]
             v[Results[i]]=1           
             rows=[str(i),str(image_ls[1]),str(Char_ls[i]),str(v[0]),str(v[1]),str(v[2])]
             writer.writerow(rows)

print("File csv Results create")